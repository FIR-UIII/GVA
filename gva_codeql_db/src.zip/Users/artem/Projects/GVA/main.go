package main

import (
    "github.com/FIR_UIII/GVA/xss" // Import the xss package
)

func main() {
    xss.XSS() // Call the XSS function from the xss package
}